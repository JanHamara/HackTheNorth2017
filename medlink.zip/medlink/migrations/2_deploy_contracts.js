var MedLink = artifacts.require("./MedLink.sol");

module.exports = function(deployer) {
  deployer.deploy(MedLink);
};
