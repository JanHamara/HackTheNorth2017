export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyAvOMBt8ZAP2bz_O4MDB9W8vglfqYSGpLY',
    authDomain: 'medlink-43c79.firebaseapp.com',
    databaseURL: 'https://medlink-43c79.firebaseio.com',
    projectId: 'medlink-43c79',
    storageBucket: 'medlink-43c79.appspot.com',
    messagingSenderId: '575898077779'
  }
};
